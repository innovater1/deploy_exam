CREATE TABLE member (
	`memberEmail` VARCHAR(20) NOT NULL,
	`passwd` VARCHAR(15) NOT NULL,
	`memberName` VARCHAR(10) NOT NULL,
	`phone` VARCHAR(20),
	PRIMARY KEY (memberEmail)
);